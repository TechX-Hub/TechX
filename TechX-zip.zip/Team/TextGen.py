techx_intro_text = """TechX
Hey everyone 👋
I wanted to officially introduce you to something I’ve been building  TechX.
TechX is a small but intentional programming hub made up of young minds who genuinely share an interest in coding, building, and growing. I handpicked each of you because at some point we connected over tech, ideas, or curiosity  and that’s exactly what this space is about.
The core idea behind TechX is simple:
A place to share ideas, innovate, renovate, and elevate  together.
This isn’t about competition or showing off skills. It’s about:
Learning from one another
Collaborating across different stacks
Building real world projects, not just tutorials
Growing from where we are to where we want to be
Right now, we’ve got a mix of Python developers and a strong base of web developers, which is honestly a great foundation. Over time, the goal is to expand our skills, our projects, and our impact  step by step.
There’s no pressure here. Just curiosity, consistency, and community.
"""

techx_team_txt = """
Members
Raymond
Ghost rider
Bill
Elsie
Axiomghost
Flirty roman
Brinnly barret
Centrozon 
Diamond 
Finnky
Prudence

Senior developers
Elsie
Diamond
Ghost rider
Raymond
"""

techx_roles_text = """
Developer Roles:

Backend Developers
Diamond
Ghost rider

Frontend Developers
Raymond
Bill
Elsie
Axiomghost
Flirty roman
Brinnly barret
Centrozon
Finnky
Prudence
"""

def writeToFile(filepath, text):
    with open(f"{filepath}.txt", "w", encoding="utf-8") as file:
        file.write(text)

# Write files
writeToFile("TechX-intro", techx_intro_text)
writeToFile("TechX-members", techx_team_txt)
writeToFile("TechX-roles", techx_roles_text)