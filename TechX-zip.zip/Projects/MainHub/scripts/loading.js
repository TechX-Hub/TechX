// loading.js

function waitMinimumTime(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function checkAuthState() {
  return new Promise(resolve => {
    const user = localStorage.getItem("user");
    const isLoggedIn = localStorage.getItem("isLoggedIn");

    resolve(user && isLoggedIn === "true");
  });
}

async function initApp() {
  // Phase 1 + Phase 2 together
  const [_, isAuthenticated] = await Promise.all([
    waitMinimumTime(3000),   // minimum loading time
    checkAuthState()         // auth readiness
  ]);

  if (isAuthenticated) {
    window.location.href = "home.html";
  } else {
    window.location.href = "auth.html";
  }
}

initApp();

